#!/bin/sh
#change to the directory get-map-info.php is in
cd /home/kg6wxc/MeshMap/scripts
./get-map-info.php
